@extends('layouts.front')

@section('content')
    
@endsection