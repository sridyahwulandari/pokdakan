<footer class="footer">
    <div class="container-fluid">
        <nav class="pull-left">
            <ul class="nav">
                
            </ul>
        </nav>
        <div class="copyright ml-auto">
            Produktivitas Budidaya Perikanan <i class="fa fa-heart heart text-danger"></i>
        </div>				
    </div>
</footer>