<?php $__env->startSection('content'); ?>
   

<div class="panel-header bg-primary-gradient">
	<div class="page-inner py-5">
		<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
		</div>
	</div>
</div>
<div class="page-inner mt--5">
	<div class="row">
		<div class="col-md-12">
			<div class="card full-height">
				<div class="card-header">
					<div class="card-head-row">
						<div class="card-title">Aktivitas Budidaya Ikan</div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('jadwal-create')): ?>
                        <a href="<?php echo e(route('jadwal.create')); ?>" class="btn btn-primary btn-sm ml-auto"><i class="fa fa-plus"></i>Tambah Produk</a>
                        <?php endif; ?>
					</div>
				</div>
				<div class="card-body">
                    <?php if(Session::has('success')): ?>

                        <div class="alert alert-primary">
                            <?php echo e(Session('success')); ?>

                        </div>
                    <?php endif; ?>
					<div class="table-responsive">
					<table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Tambak</th>
                                <th>Tanggal Tabur Bibit</th>
                                <th>Jumlah Benih</th>
                                <th>Tanggal Tabur Pakan</th>
                                <th>Jumlah Pakan</th>
                                <th>Jenis Pakan</th>
                                <th>Usia Tambak</th>
                                <th>Prediksi Panen</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($row->tambak->nama_tambak); ?></td>
                                <td><?php echo e($row->tgl_bibit); ?></td>
                                <td><?php echo e($row->jumlah_bibit); ?></td>
                                <td><?php echo e($row->tgl_pakan); ?></td>
                                <td><?php echo e($row->jumlah_pakan); ?></td>
                                <td><?php echo e($row->jenis_pakan); ?></td>
                                <td><?php echo e($row->usia_tambak); ?></td>
                                <td><?php echo e($row->tgl_panen); ?></td>
                                <td>
                                    
                                    <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                                        <div class="btn-group" role="group">
                                          <button id="btnGroupDrop1" type="button" class="btn btn-danger dropdown-toggle btn-sm" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Tebar Bibit
                                          </button>
                                          <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                            <a class="dropdown-item" href="/pembesaran/update-panen/<?php echo e($row->id); ?>">Pembesaran</a>
                                            <a class="dropdown-item" href="">Panen</a>
                                          </div>
                                        </div>
                                    </div>
    
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center">Data Masih Kosong</td>
                            </tr>
                            <?php endif; ?>
                          
                        </tbody>
                    </table>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/jadwal/index.blade.php ENDPATH**/ ?>