
<?php $__env->startSection('content'); ?>
   

<div class="panel-header bg-primary-gradient">
	<div class="page-inner py-5">
		<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
		</div>
	</div>
</div>
<div class="page-inner mt--5">
	<div class="row">
		<div class="col-md-12">
			<div class="card full-height">
				<div class="card-header">
					<div class="card-head-row">
						<div class="card-title">Blog</div>
                        <a href="<?php echo e(route('blog.index')); ?>" class="btn btn-warning btn-sm ml-auto">Back</a>
					</div>
				</div>
				<div class="card-body">
                <form method="post" action="<?php echo e(route('blog.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group">
                        <label for="karegori_blog">Kategori Blog</label>
                        <select name="kategori_blog" class="form-control">
                            <option value="berita">Berita & Acara</option>
                            <option value="cerita">Cerita Budidaya</option>
                            <option value="tips">Cerita Budidaya</option>
                            <option value="lain">Lainnya</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="judul_blog">Judul Blog</label>
                        <input type="text" name="judul_blog" class="form-control" id="text" placeholder="Enter Judul Blog">
                    </div>

                    <div class="form-group">
                        <label for="deskripsi">Deskripsi</label>
                        <input type="text" name="deskripsi" class="form-control" id="text" placeholder="Enter Deskripsi">
                    </div>

                    <div class="form-group">
                        <label for="gambar_blog">Gambar Blog</label>
                        <input type="file" name="gambar_blog" class="form-control">
                    </div>

                    <div class="form-group">
                        <button class="btn btn-primary btn-sm" type="submit">Save</button>
                        <button class="btn btn-primary btn-sm" type="reset">Reset</button>
                    </div>
                </form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/blog/create.blade.php ENDPATH**/ ?>