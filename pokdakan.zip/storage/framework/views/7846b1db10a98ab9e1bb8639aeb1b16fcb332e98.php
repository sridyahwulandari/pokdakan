
<?php $__env->startSection('content'); ?>
   

<div class="panel-header bg-primary-gradient">
	<div class="page-inner py-5">
		<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
		</div>
	</div>
</div>
<div class="page-inner mt--5">
	<div class="row">
		<div class="col-md-12">
			<div class="card full-height">
				<div class="card-header">
					<div class="card-head-row">
						<div class="card-title">Edit Kolam <?php echo e($tambak->kode_tambak); ?></div>
                        <a href="<?php echo e(route('tambak.index')); ?>" class="btn btn-warning btn-sm ml-auto">Back</a>
					</div>
				</div>
				<div class="card-body">
                <form method="post" action="<?php echo e(route('tambak.update', $tambak->id)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="form-group">
                        <label for="kode_tambak">Kode Tambak</label>
                        <input type="text" name="kode_tambak" class="form-control" id="text" 
                        value="<?php echo e($tambak->kode_tambak); ?>">
                    </div>

                    <div class="form-group">
                        <label for="nama_tambak">Nama Tambak</label>
                        <input type="text" name="nama_tambak" class="form-control" id="text" 
                        value="<?php echo e($tambak->nama_tambak); ?>">
                    </div>

                    <div class="form-group">
                        <label for="luas_tambak">Luas Tambak</label>
                        <input type="text" name="luas_tambak" class="form-control" id="text" 
                        value="<?php echo e($tambak->luas_tambak); ?>">
                    </div>

                    <div class="form-group">
                        <label for="kedalaman">Kedalaman</label>
                        <input type="text" name="kedalaman" class="form-control" id="text" 
                        value="<?php echo e($tambak->kedalaman); ?>">
                    </div>

                    <div class="form-group">
                        <label for="kapasitas_ikan">Kapasitas Ikan</label>
                        <input type="text" name="kapasitas_ikan" class="form-control" id="text" 
                        value="<?php echo e($tambak->kapasitas_ikan); ?>">
                    </div>

                    

                    <div class="form-group">
                        <label for="gambar_tambak">Gambar tambak</label>
                        <input type="file" name="gambar_tambak" class="form-control">
                        <br>
                        <label for="gambar">Gambar Saat Ini</label><br>
                        <img src=" <?php echo e(asset('uploads/' . $tambak->gambar_tambak)); ?> " width="100">
                    </div>

                    <div class="form-group">
                        <label for="status">Status</label>
                        <select name="status" class="form-control">
                            <option value="1" <?php echo e($tambak->status == '1' ? 'selected' : ''); ?>>
                                Aktif
                            </option>
                            <option value="0"<?php echo e($tambak->status == '0' ? 'selected' : ''); ?>>
                                Tidak Aktif
                            </option>
                        </select>
                    </div>

                    <div class="form-group">
                        <button class="btn btn-primary btn-sm" type="submit">Save</button>
                        <button class="btn btn-primary btn-sm" type="reset">Reset</button>
                    </div>
                </form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/tambak/edit.blade.php ENDPATH**/ ?>