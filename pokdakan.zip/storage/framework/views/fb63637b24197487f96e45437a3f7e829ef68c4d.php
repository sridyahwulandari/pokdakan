<footer class="footer">
    <div class="container-fluid">
        <nav class="pull-left">
            <ul class="nav">
                
            </ul>
        </nav>
        <div class="copyright ml-auto">
            Produktivitas Budidaya Perikanan <i class="fa fa-heart heart text-danger"></i>
        </div>				
    </div>
</footer><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/layouts/include/footer.blade.php ENDPATH**/ ?>