
<?php $__env->startSection('content'); ?>
<div class="panel-header bg-primary-gradient">
	<div class="page-inner py-5">
		<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
		</div>
	</div>
</div>
<div class="page-inner mt--5">
	<div class="row">
		<div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center">
                        <h4 class="card-title">Data Permission</h4>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-create')): ?>
                        <a href="<?php echo e(route('permissions.create')); ?>" class="btn btn-primary btn-sm ml-auto"><i class="fa fa-plus"></i>Tambah Permission</a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
        
                    <div class="table-responsive">
                        <table id="add-row" class="display table table-striped table-hover" >
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration ?? ''); ?></td>
                                <td><?php echo e($permission->name); ?></td>
                                <td>
                                    <div class="form-button-action">
                                        <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-success btn-lg" data-original-title="Show Permission">
                                            <a href="<?php echo e(route('permissions.show',$permission->id)); ?>"><i class="fa fa-eye"></i></a>
                                        </button>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                                        <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Permission">
                                            <a href="<?php echo e(route('permissions.edit',$permission->id)); ?>"><i class="fa fa-edit"></i></a>
                                        </button>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
                                        <?php echo Form::open(['method' => 'DELETE','route' => ['permissions.destroy', $permission->id],'style'=>'display:inline']); ?>

                                        <?php echo Form::button('<i class="fa fa-trash"></i>', ['class' => 'btn btn-link btn-danger btn-lg', 'type' => 'button', ' data-toggle' => 'tooltip', 'type' => 'button',  'data-original-title' => 'Hapus Permission']); ?>

                                        <?php echo Form::close(); ?>

                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">Data Masih Kosong</td>
                            </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/permissions/index.blade.php ENDPATH**/ ?>