<?php echo e($slot); ?>

<?php /**PATH G:\Tugas Akhir\pokdakan\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>