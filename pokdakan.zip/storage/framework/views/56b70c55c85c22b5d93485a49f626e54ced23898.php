

<?php $__env->startSection('content'); ?>
    <!-- ======= Values Section ======= -->
    <section id="values" class="values">

        <div class="container" data-aos="fade-up">
  
          <header class="section-header">
            <p>Solusi Kami untuk Dunia Perikanan</p>
          </header>
  
          <div class="row">
  
            <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
              <div class="box">
                <img src="<?php echo e(asset('web/img/values-1.png')); ?>" class="img-fluid" alt="">
                <h3>Solusi Untuk Pembudidaya Ikan Air Tawar</h3>
                <p>Eum ad dolor et. Autem aut fugiat debitis voluptatem consequuntur sit. Et veritatis id.</p>
              </div>
            </div>
  
            <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="400">
              <div class="box">
                <img src="<?php echo e(asset('web/img/values-2.png')); ?>" class="img-fluid" alt="">
                <h3>Solusi Untuk Pembudidaya Ikan Air Tawar</h3>
                <p>Repudiandae amet nihil natus in distinctio suscipit id. Doloremque ducimus ea sit non.</p>
              </div>
            </div>
  
            <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="600">
              <div class="box">
                <img src="<?php echo e(asset('web/img/values-3.png')); ?>" class="img-fluid" alt="">
                <h3>Solusi Untuk Pembeli & Konsumen</h3>
                <p>Quam rem vitae est autem molestias explicabo debitis sint. Vero aliquid quidem commodi.</p>
              </div>
            </div>
  
          </div>
  
        </div>
  
      </section><!-- End Values Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/frontend/home/index.blade.php ENDPATH**/ ?>