

<?php $__env->startSection('content'); ?>

<br>
<br>
    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">

        <div class="row">
          
          <div class="col-lg-8 entries">
            <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <article class="entry">

              <div class="entry-img">
                <img src="<?php echo e(asset('uploads/'. $row->gambar_berita)); ?>" alt="" class="img-fluid">
              </div>

              <h2 class="entry-title">
                <a href=""><?php echo e($row->judul_berita); ?></a>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a href="blog-single.html"><?php echo e($row->users->name); ?></a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="blog-single.html"><time><?php echo e($row->created_at); ?></time></a></li>
                </ul>
              </div>

              <div class="entry-content">
                <div class="read-more">
                  <a href="<?php echo e(route('berita-front-detail', $row->slug)); ?>">Baca Selengkapnya</a>
                </div>
              </div>

            </article><!-- End blog entry -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div><!-- End blog entries list -->
          <div class="col-lg-4">

            <div class="sidebar">
              <h3 class="sidebar-title">Recent Posts</h3>
              <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="sidebar-item recent-posts">
                <div class="post-item clearfix">
                  <img src="<?php echo e(asset('uploads/'. $row->gambar_berita)); ?>" alt="">
                  <h4><a href="<?php echo e(route('berita-front-detail', $row->slug)); ?>"><?php echo e($row->judul_berita); ?></a></h4>
                  <time><?php echo e($row->created_at); ?></time>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div><!-- End sidebar recent posts-->

            </div><!-- End sidebar -->

          </div><!-- End blog sidebar -->
          
        </div>

      </div>
    </section><!-- End Blog Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/frontend/berita-front/index.blade.php ENDPATH**/ ?>