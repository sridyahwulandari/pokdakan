<div class="form-group"> 
    <label class="col-sm-2 control-label">Buat Tugas</label>  
 
    <?php echo Form::open(['url'=>'tugas/simpan','class'=>'form-horizontal', 'enctype' => 'multipart/form-data']); ?>        
    <?php if($errors->any()): ?>     
    <div class="alert alert-danger">         
     <ul>             
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                 
         <li><?php echo e($error); ?></li>            
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
     </ul>     
   </div>  
   <?php endif; ?> 
 
  <div class="col-sm-5">   
   <?php echo Form::text('nama_tugas',null,['class'=>'formcontrol','placeholder'=>"nama_tugas"]); ?>  </div>
   <div class="col-sm-5">   
     <?php echo Form::text('end_date',null,['class'=>'formcontrol','placeholder'=>"mm/dd/yyyy"]); ?>  </div>
 
     <div class="form-group row mb-0">
       <div class="col-md-8 offset-md-4">
         <button type="submit" class="btn btn-primary">
           <?php echo e(__('Tambah')); ?>

         </button>
       </div>
     </div>
     <?php echo Form::close(); ?>

   </div><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/tugas/tambah.blade.php ENDPATH**/ ?>