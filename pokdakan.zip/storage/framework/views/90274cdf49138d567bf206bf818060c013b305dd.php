

<?php $__env->startSection('content'); ?>

<br>
<br>
    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <?php $__currentLoopData = $edukasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-8 entries">

            <article class="entry">

              <div class="entry-img">
                <img src="<?php echo e(asset('uploads/'. $row->gambar_edukasi)); ?>" alt="" class="img-fluid">
              </div>

              <h2 class="entry-title">
                <a href=""><?php echo e($row->judul_edukasi); ?></a>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a href="blog-single.html"><?php echo e($row->users->name); ?></a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="blog-single.html"><time><?php echo e($row->created_at); ?></time></a></li>
                </ul>
              </div>

              <div class="entry-content">
                <div class="read-more">
                  <a href="<?php echo e(route('edukasi-front-detail', $row->slug)); ?>">Baca Selengkapnya</a>
                </div>
              </div>

            </article><!-- End blog entry -->

          </div><!-- End blog entries list -->

          <div class="col-lg-4">

            <div class="sidebar">

              <h3 class="sidebar-title">Edukasi</h3>
              <div class="sidebar-item recent-posts">
                <div class="post-item clearfix">
                  <img src="<?php echo e(asset('uploads/'. $row->gambar_edukasi)); ?>" alt="">
                  <h4><a href="blog-single.html"><?php echo e($row->judul_edukasi); ?></a></h4>
                  <time><?php echo e($row->created_at); ?></time>
                </div>

              </div><!-- End sidebar recent posts-->

            </div><!-- End sidebar -->

          </div><!-- End blog sidebar -->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

      </div>
    </section><!-- End Blog Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/frontend/edukasi-front/index.blade.php ENDPATH**/ ?>