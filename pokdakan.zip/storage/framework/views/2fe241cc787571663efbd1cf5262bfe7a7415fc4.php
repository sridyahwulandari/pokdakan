<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>Produktivitas Budidaya Ikan | POKDAKAN</title>
</head>
<body>
    <p>Hallo <b><?php echo e($details['nama']); ?></b> berikut ini adalah komentar Anda:</p>
    <table>
      <tr>
        <td>Nama Lengkap</td>
        <td>:</td>
        <td><?php echo e($details['nama']); ?></td>
      </tr>
      <tr>
        <td>Judul</td>
        <td>:</td>
        <td><?php echo e($details['judul']); ?></td>
      </tr>
      <tr>
        <td>Pesan</td>
        <td>:</td>
        <td><?php echo e($details['pesan']); ?></td>
      </tr>
    </table>
    <p>Terimakasih <b><?php echo e($details['nama']); ?></b> telah memberi komentar.</p>
</body>
</html><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/frontend/hubungi-kami/mailtemplate.blade.php ENDPATH**/ ?>