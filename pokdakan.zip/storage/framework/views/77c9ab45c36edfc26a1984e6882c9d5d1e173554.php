

<?php $__env->startSection('content'); ?>
<br>
<br>
    <!-- ======= Blog Single Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">
        <header class="section-header">
          <p>Produk Ikan Air Tawar & Ikan Air Payau</p>
        </header>
        <div class="row">
          
          <div class="col-lg-8 entries">

            <article class="entry entry-single">

              <div class="entry-gambar">
                <img src="<?php echo e(asset('uploads/'. $produk->gambar_produk_supplier)); ?>" alt=""  class="img-fluid">
              </div>

              <h2 class="entry-title">
                <a href=""><?php echo e($produk->supplier->bahan_baku); ?> - <?php echo e($produk->jenis_pakan); ?></a>
              </h2>

              <div class="entry-meta">
                <ul>
                  <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a href="blog-single.html"><?php echo e($produk->users->name); ?></a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="blog-single.html"><time datetime=""><?php echo e($produk->created_at); ?></time></a></li>
                  <li class="d-flex align-items-center"><i class="bi bi-chat-dots"></i> <a href="blog-single.html"><td>
                    <?php if($produk->status == '1'): ?>
                        Tersedia
                        <?php else: ?>
                        Habis
                        <?php endif; ?>
                </td></a></li>
                </ul>
              </div>

              <div class="entry-content">
                <p>
                  <?php echo $produk->deskripsi; ?>

                </p>
              <h3>Daftar Harga <?php echo e($produk->jenis_pakan); ?> Per Kilogram</h3>
                <table class="col-md-8">
                  <tr>
                      <th>Author</th>
                      <th>Kategori</th>
                      <th>Jenis Ikan</th>
                      <th>Harga</th>
                      <th>Stok</th>
                  </tr>
                  <tr>
                      <td align="center"><?php echo e($produk->users->name); ?></td>
                      <td align="center"><?php echo e($produk->supplier->bahan_baku); ?></td>
                      <td align="center"><?php echo e($produk->jenis_pakan); ?></td>
                      <td align="center">Rp. <?php echo e($produk->harga); ?>/Kg</td>
                      <td align="center"><?php echo e($produk->stok); ?>/Kg</td>
                  </tr>
                </table>
                    
            </article><!-- End blog entry -->
            
        </div>
        <div class="col-lg-4">
          <div class="sidebar">

            <h3 class="sidebar-title">Supplier</h3>
            
            <div class="sidebar-item recent-posts">
              <div class="post-item clearfix">
                <img src="<?php echo e(asset('uploads/'. $produk->users->foto)); ?>" alt="">
              </div> 
              <p><?php echo e($produk->users->name); ?></p>
                <p><?php echo e($produk->users->alamat); ?></p>
                <p><?php echo e($produk->users->telepon); ?></p>
                <a href="https://api.whatsapp.com/send?phone=<?php echo e($produk->users->telepon); ?>&text=Hallo%20Minat"><img src="<?php echo e(asset('web/img/hubungiwa.png')); ?>"></a>
            </div><!-- End sidebar recent posts-->
	


          </div><!-- End sidebar -->
        </div><!-- End blog sidebar -->
      
    </div>

    </section><!-- End Blog Single Section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/frontend/produk-front-detail/index.blade.php ENDPATH**/ ?>