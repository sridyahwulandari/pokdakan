<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<!--   Head   -->
<?php echo $__env->make('layouts.frontend.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--   End Head   -->

<body>

 <!--   Header   -->
 <?php echo $__env->make('layouts.frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <!--   End Header   -->

  <main id="main">
    <?php echo $__env->yieldContent('content'); ?>


  </main><!-- End #main -->

<!--   Footer   -->
<?php echo $__env->make('layouts.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--   End Footer   -->

<!--   JS   -->
<?php echo $__env->make('layouts.frontend.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--   End JS  -->
</body>

</html><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/layouts/front.blade.php ENDPATH**/ ?>