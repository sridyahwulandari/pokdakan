
<?php $__env->startSection('content'); ?>
   

<div class="panel-header bg-primary-gradient">
	<div class="page-inner py-5">
		<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
		</div>
	</div>
</div>
<div class="page-inner mt--5">
	<div class="row">
		<div class="col-md-12">
			<div class="card full-height">
				<div class="card-header">
					<div class="card-head-row">
						<div class="card-title">Edit Pembudidaya <i><?php echo e($pembudidaya->kategori_pembudidaya); ?></i></div>
                        <a href="<?php echo e(route('pembudidaya.index')); ?>" class="btn btn-warning btn-sm ml-auto">Back</a>
					</div>
				</div>
				<div class="card-body">
                <form method="post" action="<?php echo e(route('pembudidaya.update', $pembudidaya->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="kategori_pembudidaya">Kategori Pembudidaya</label>
                        <input type="text" name="kategori_pembudidaya" value="<?php echo e($pembudidaya->kategori_pembudidaya); ?>" class="form-control" placeholder="Enter Kategori Pengepul">
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary btn-sm" type="submit">Save</button>
                    </div>
                </form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/pembudidaya/edit.blade.php ENDPATH**/ ?>