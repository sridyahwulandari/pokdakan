		<!-- Sidebar -->
		<div class="sidebar sidebar-style-2">			
			<div class="sidebar-wrapper scrollbar scrollbar-inner">
				<div class="sidebar-content">
					<div class="user">
						<div class="avatar-sm float-left mr-2">
							<img src="<?php echo e(asset('uploads/' . auth()->user()->foto)); ?>" alt="..." class="avatar-img rounded-circle">
						</div>
						<div class="info">
							<a data-toggle="collapse" href="#collapseExample" aria-expanded="true">
								<span>
									<?php echo e(auth()->user()->name); ?>

									<span class="caret"></span>
								</span>
							</a>
							<div class="clearfix"></div>

							<div class="collapse in" id="collapseExample">
								<ul class="nav">
									<li>
										<a href="<?php echo e(route('user.myProfile')); ?>">
											<span class="link-collapse">My Profile</span>
										</a>
									</li>
									<li>
										<a href="<?php echo e(route('user.profile')); ?>">
											<span class="link-collapse">Edit Profile</span>
										</a>
									</li>
									<li>
										<a href="<?php echo e(route('userGetPassword')); ?>">
											<span class="link-collapse">Settings</span>
										</a>
									</li>
									<li>
										<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
											<span class="link-collapse">Logout</span>
											<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
												<?php echo csrf_field(); ?>
											</form></a>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<ul class="nav nav-primary">
						<li class="nav-item active">
							<a  href="<?php echo e(route('home')); ?>">
								<i class="fas fa-home"></i>
								<p>Dashboard</p>
							</a>
						</li>
						<li class="nav-section">
							<span class="sidebar-mini-icon">
								<i class="fa fa-ellipsis-h"></i>
							</span>
							<h4 class="text-section">Components</h4>
						</li>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-list')): ?>
						<li class="nav-item">
							<a data-toggle="collapse" href="#forms">
								<i class="fas fa-pen-square"></i>
								<p>Manajement</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="forms">
								<ul class="nav nav-collapse">
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-list')): ?>
									<li>
										<a href="<?php echo e(route('users.index')); ?>">
											<i class="fas fa-users"></i>
											<p>Pengguna</p>
										</a>
									</li>
									<?php endif; ?>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-list')): ?>
									<li>
										<a href="<?php echo e(route('roles.index')); ?>">
											<i class="fas fa-desktop"></i>
											<p>Role</p>
										</a>
									</li>
									<?php endif; ?>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-list')): ?>
									<li>
										<a href="<?php echo e(route('permissions.index')); ?>">
											<i class="fas fa-desktop"></i>
											<p>Permission</p>
										</a>
									</li>
									<?php endif; ?>
								</ul>
							</div>
						</li>
						<li class="nav-item">
							<a data-toggle="collapse" href="#base">
								<i class="fas fa-pen-square"></i>
								<p>Master Data</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="base">
								<ul class="nav nav-collapse">
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier-list')): ?>
									<li>
										<a href="<?php echo e(route('supplier.index')); ?>">
											<i class="fas fa-user-shield"></i>
											<p>Supplier</p>
										</a>
									</li>
									<?php endif; ?>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pembudidaya-list')): ?>
									<li>
										<a href="<?php echo e(route('pembudidaya.index')); ?>">
											<i class="fas fa-users-cog"></i>
											<p>Pembudidaya</p>
										</a>
									</li>
									<?php endif; ?>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pengepul-list')): ?>
									<li>
										<a href="<?php echo e(route('pengepul.index')); ?>">
											<i class="fas fa-user-tag"></i>
											<p>Pengepul</p>
										</a>
									</li>
									<?php endif; ?>
								</ul>
							</div>
						</li>
						<?php endif; ?>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('berita-list')): ?>
						<li class="nav-item">
							<a data-toggle="collapse" href="#tables">
								<i class="fas fa-newspaper"></i>
								<p>Konten</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="tables">
								<ul class="nav nav-collapse">
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('berita-list')): ?>
									<li>
										<a href="<?php echo e(route('berita.index')); ?>">
											<i class="far fa-newspaper"></i>
											<p>Kelola Berita & Edukasi</p>
										</a>
									</li>
									<?php endif; ?>
								</ul>
							</div>
						</li>
						<?php endif; ?>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produk')): ?>
						<li class="nav-item">
							<a data-toggle="collapse" href="#sidebarLayouts">
								<i class="fas fa-table"></i>
								<p>Supplier</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="sidebarLayouts">
								<ul class="nav nav-collapse">
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produk-supplier')): ?>
									<li>
										<a href="<?php echo e(route('produk.index')); ?>">
											<span class="sub-item">Produk Supplier</span>
										</a>
									</li>
									<?php endif; ?>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('produk-tersedia')): ?>
									<li>
										<a href="<?php echo e(route('produk.produktersedia')); ?>">
											<span class="sub-item">Produk Tersedia</span>
										</a>
									</li>
									<?php endif; ?>
								</ul>
							</div>
						</li>
						<?php endif; ?>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('budidaya-list')): ?>
						<li class="nav-item">
							<a data-toggle="collapse" href="#submenu">
								<i class="fas fa-fish"></i>
								<p>Pembudidaya</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="submenu">
								<ul class="nav nav-collapse">
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tambak-list')): ?>
									<li>
										<a href="<?php echo e(route('tambak.index')); ?>">
											<span class="sub-item">Data Tambak</span>
										</a>
									</li>
									<?php endif; ?>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('jadwal-list')): ?>
									<li>
										<a data-toggle="collapse" href="#subnav1">
											<span class="sub-item">Data Jadwal</span>
											<span class="caret"></span>
										</a>
										<div class="collapse" id="subnav1">
											<ul class="nav nav-collapse subnav">
												<li>
													<a href="<?php echo e(route('jadwal.index')); ?>">
														<span class="sub-item">Tebar Benih</span>
													</a>
												</li>
												<li>
													<a href="<?php echo e(route('pembesaran.index')); ?>">
														<span class="sub-item">Pembesaran Ikan</span>
													</a>
												</li>
												<li>
													<a href="<?php echo e(route('panen.index')); ?>">
														<span class="sub-item">Panen</span>
													</a>
												</li>
											</ul>
										</div>
									</li>
									<?php endif; ?>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('aktivitas')): ?>
									<li>
										<a href="<?php echo e(route('aktivitas.index')); ?>">
											<span class="sub-item">Aktvitas Pembudidaya</span>
										</a>
									</li>
									<?php endif; ?>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kebutuhan-pembudidaya-list')): ?>
									<li>
										<a href="<?php echo e(route('kebutuhan-pembudidaya.index')); ?>">
											<span class="sub-item">Kebutuhan Budidaya</span>
										</a>
									</li>
									<?php endif; ?>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kebutuhan-pembudidaya-detail')): ?>
									<li>
										<a href="<?php echo e(route('kebutuhanpembudidaya.detailkebutuhanpembudidaya')); ?>">
											<span class="sub-item">Kebutuhan Pembudidaya</span>
										</a>
									</li>
									<?php endif; ?>
								</ul>
							</div>
						</li>
						<?php endif; ?>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kebutuhan-pengepul')): ?>
						<li class="nav-item">
							<a data-toggle="collapse" href="#charts">
								<i class="fas fa-user"></i>
								<p>Pengepul</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="charts">
								<ul class="nav nav-collapse">
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kebutuhan-pengepul-list')): ?>
									<li>
										<a href="<?php echo e(route('kebutuhan-pengepul.index')); ?>">
											<span class="sub-item">Kebutuhan Pengepul</span>
										</a>
									</li>
									<?php endif; ?>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kebutuhan-pengepul-detail')): ?>
									<li>
										<a href="<?php echo e(route('kebutuhanpengepul.detailkebutuhanpengepul')); ?>">
											<span class="sub-item">Kebutuhan Pengepul</span>
										</a>
									</li>
									<?php endif; ?>
								</ul>
							</div>
						</li>
						<?php endif; ?>
					</ul>
				</div>
			</div>
		</div>
		<!-- End Sidebar --><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/layouts/include/sidebar.blade.php ENDPATH**/ ?>