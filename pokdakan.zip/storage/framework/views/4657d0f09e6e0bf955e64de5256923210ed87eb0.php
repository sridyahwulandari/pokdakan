
<?php $__env->startSection('content'); ?>
   

<div class="panel-header bg-primary-gradient">
	<div class="page-inner py-5">
		<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
		</div>
	</div>
</div>
<div class="page-inner mt--5">
	<div class="row">
		<div class="col-md-12">
			<div class="card full-height">
				<div class="card-header">
					<div class="card-head-row">
						<div class="card-title">Data Acara</div>
                        <a href="<?php echo e(route('acara.create')); ?>" class="btn btn-primary btn-sm ml-auto"><i class="fa fa-plus"></i>Tambah Acara</a>
					</div>
				</div>
				<div class="card-body">
                    <?php if(Session::has('success')): ?>

                        <div class="alert alert-primary">
                            <?php echo e(Session('success')); ?>

                        </div>
                    <?php endif; ?>
					<div class="table-responsive">
					<table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tanggal Mulai</th>
                                <th>Taggal Selesai</th>
                                <th>Status</th>
                                <th>Gambar Produk</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $acara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($row->id); ?></td>
                                <td><?php echo e($row->tgl_mulai); ?></td>
                                <td><?php echo e($row->launch_date); ?></td>
                                <td>
                                    <?php if($row->status == '1'): ?>
                                        Inactive
                                        <?php else: ?>
                                        Active
                                        <?php endif; ?>
                                </td>
                                <td><img src=" <?php echo e(asset('uploads/' . $row->gambar_produk)); ?> " width="100"></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">Data Masih Kosong</td>
                            </tr>
                            <?php endif; ?>
                          
                        </tbody>
                    </table>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/acara/index.blade.php ENDPATH**/ ?>