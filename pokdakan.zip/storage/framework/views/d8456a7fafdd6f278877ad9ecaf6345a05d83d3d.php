<?php $__env->startSection('content'); ?>
   

<div class="panel-header bg-primary-gradient">
	<div class="page-inner py-5">
		<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
		</div>
	</div>
</div>
<div class="page-inner mt--5">
	<div class="row">
		<div class="col-md-12">
			<div class="card full-height">
				<div class="card-header">
					<div class="card-head-row">
						<div class="card-title">Data Kebutuhan Pembudidaya</div>
                        <a href="<?php echo e(route('kebutuhan-pembudidaya.create')); ?>" class="btn btn-primary btn-sm ml-auto"><i class="fa fa-plus"></i>Tambah Produk</a>
					</div>
				</div>
				<div class="card-body">
                    <?php if(Session::has('success')): ?>

                        <div class="alert alert-primary">
                            <?php echo e(Session('success')); ?>

                        </div>
                    <?php endif; ?>
					<div class="table-responsive">
					<table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Kategori Produk</th>
                                <th>Kategori Budidaya</th>
                                <th>Tanggal Kebutuhan</th>
                                <th>Nama</th>
                                <th>Jenis</th>
                                <th>Jumlah</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $kebutuhanpembudidaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($row->supplier->bahan_baku); ?></td>
                                <td><?php echo e($row->pembudidaya->kategori_pembudidaya); ?></td>
                                <td><?php echo e($row->tgl_kebutuhan); ?></td>
                                <td><?php echo e($row->nama); ?></td>
                                <td><?php echo e($row->jenis); ?></td>
                                <td><?php echo e($row->jumlah); ?></td>
                                <td>
                                    <div class="form-button-action">
                                        
                                        <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Detail Produk">
                                            <a href="<?php echo e(route('kebutuhan-pembudidaya.show', $row->id)); ?>"><i class="fa fa-eye"></i></a>
                                        </button>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kebutuhan-pembudidaya-edit')): ?>
                                        <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Produk">
                                            <a href="<?php echo e(route('kebutuhan-pembudidaya.edit', $row->id)); ?>"><i class="fa fa-edit"></i></a>
                                        </button>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kebutuhan-pembudidaya-delete')): ?>
                                        <form action="<?php echo e(route('kebutuhan-pembudidaya.destroy', $row->id)); ?>" method="post" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                        <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Hapus">
                                            <i class="fa fa-times"></i>
                                        </button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">Data Masih Kosong</td>
                            </tr>
                            <?php endif; ?>
                          
                        </tbody>
                    </table>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/kebutuhan-pembudidaya/index.blade.php ENDPATH**/ ?>