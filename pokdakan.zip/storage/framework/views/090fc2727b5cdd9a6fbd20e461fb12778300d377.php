
<?php $__env->startSection('content'); ?>
   

<div class="panel-header bg-primary-gradient">
	<div class="page-inner py-5">
		<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
		</div>
	</div>
</div>
<div class="page-inner mt--5">
	<div class="row">
		<div class="col-md-12">
			<div class="card full-height">
				<div class="card-header">
					<div class="card-head-row">
						<div class="card-title">Edit Trend <?php echo e($trend->jenis_ikan); ?></div>
                        <a href="<?php echo e(route('trend.index')); ?>" class="btn btn-warning btn-sm ml-auto">Back</a>
					</div>
				</div>
				<div class="card-body">
                <form method="post" action="<?php echo e(route('trend.update', $trend->id)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="form-group">
                        <label for="kategori">Kategori</label>

                        <select name="kategori_id" class="form-control">
                            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($row->id == $trend->kategori_id): ?>
                            <option value=<?php echo e($row->id); ?> selected='selected'> <?php echo e($row->nama_kategori); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($row->id); ?>">
                                <?php echo e($row->nama_kategori); ?></option>
                                
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="jenis_ikan">Jenis Ikan</label>
                        <input type="text" name="jenis_ikan" class="form-control" id="text" 
                        value="<?php echo e($trend->jenis_ikan); ?>">
                    </div>

                    <div class="form-group">
                        <label for="harga">Harga</label>
                        <input type="text" name="harga" class="form-control" id="text" 
                        value="<?php echo e($trend->harga); ?>">
                    </div>

                    <div class="form-group">
                        <label for="tgl_mulai">Tanggal Mulai <span class="text-danger">*</span></label>
                        <input type="datetime-local" name="tgl_mulai" class="form-control" value="<?php echo e($trend->tgl_mulai); ?>"/>
                     </div>
                     <div class="form-group">
                        <label for="tgl_selesai">Tanggal Selesai <span class="text-danger">*</span></label>
                        <input type="datetime-local" name="tgl_selesai" class="form-control" value="<?php echo e($trend->tgl_selesai); ?>"/>
                     </div>

                    <div class="form-group">
                        <label for="gambar_trend">Gambar</label>
                        <input type="file" name="gambar_trend" class="form-control">
                        <br>
                        <label for="gambar">Gambar Saat Ini</label><br>
                        <img src=" <?php echo e(asset('uploads/' . $trend->gambar_trend)); ?> " width="100">
                    </div>


                    <div class="form-group">
                        <button class="btn btn-primary btn-sm" type="submit">Save</button>
                        <button class="btn btn-primary btn-sm" type="reset">Reset</button>
                    </div>
                </form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/trend/edit.blade.php ENDPATH**/ ?>