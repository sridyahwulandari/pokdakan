 <!-- ======= Header ======= -->
 <header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <img src="<?php echo e(asset('web/img/logo.png')); ?>" alt="">
        <span>POKDAKAN</span>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="<?php echo e(Request::is('beranda*') ? 'active font-bold' : ''); ?>" href="/beranda">Beranda</a></li>
          <li><a class="<?php echo e(Request::is('produk-front*') ? 'active font-bold' : ''); ?>" href="/produk-front">Produk Supplier</a></li>
          <li><a class="<?php echo e(Request::is('jadwal-front*') ? 'active font-bold' : ''); ?>" href="/jadwal-front">Jadwal Pembudidaya</a></li>
          <li><a class="<?php echo e(Request::is('berita-front*') ? 'active font-bold' : ''); ?>" href="/berita-front">Berita</a></li>
          <li><a class="<?php echo e(Request::is('formemail*') ? 'active font-bold' : ''); ?>" href="formemail">Hubungi Kami</a></li>
          <li><a class="getstarted scrollto" href="<?php echo e(route('login')); ?>">Login</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header --><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/layouts/frontend/header.blade.php ENDPATH**/ ?>