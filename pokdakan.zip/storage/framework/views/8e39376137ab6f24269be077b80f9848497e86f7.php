<?php $__env->startSection('content'); ?>
   

<div class="panel-header bg-primary-gradient">
	<div class="page-inner py-5">
		<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
		</div>
	</div>
</div>
<div class="page-inner mt--5">
	<div class="row">
        <div class="col-md-4">
            <div class="card card-post card-round">
                <img class="card-img-top" src="<?php echo e(asset('uploads/' . $produk->gambar_produk_supplier)); ?>" alt="Card image cap">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="avatar">
                            <img src="../assets/img/profile2.jpg" alt="..." class="avatar-img rounded-circle">
                        </div>
                        <div class="info-post ml-2">
                            <p class="username"><?php echo e($produk->users->name); ?></p>
                            <p class="date text-muted"><?php echo e($produk->users->telepon); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<div class="col-md-8">
			<div class="card full-height">
				<div class="card-header">
					<div class="card-head-row">
						<div class="card-title">Detail Produk <?php echo e($produk->jenis_ikan); ?></div>
                        <a href="<?php echo e(route('produk.index')); ?>" class="btn btn-warning btn-sm ml-auto">Back</a>
					</div>
				</div>
				<div class="card-body">
            <div class="col-lg-12">
                <form method="post" action="" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                    <div class="col-md-6 form-group">
                        <label for="supplier">Supplier</label>

                        <select name="supplier_id" class="form-control">
                            <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($row->id == $produk->supplier_id): ?>
                            <option value=<?php echo e($row->id); ?> selected='selected'> <?php echo e($row->bahan_baku); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($row->id); ?>">
                                <?php echo e($row->bahan_baku); ?></option>
                                
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="jenis_pakan">Jenis Pakan</label>
                        <input type="text" name="jenis_pakan" class="form-control" id="text" 
                        value="<?php echo e($produk->jenis_pakan); ?>">
                    </div>
                    </div>

                    <div class="form-group">
                        <label for="nama_produk">Nama Produk</label>
                        <input type="text" name="nama_produk" class="form-control" id="text" 
                        value="<?php echo e($produk->nama_produk); ?>">
                    </div>

                    <div class="row">
                        <div class="col-md-8 form-group">
                            <label for="merk">Merk</label>
                            <input type="text" name="merk" class="form-control" id="text" 
                            value="<?php echo e($produk->merk); ?>">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="kondisi">Kondisi</label>
                            <input type="text" name="kondisi" class="form-control" id="text" 
                            value="<?php echo e($produk->kondisi); ?>">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 form-group">
                            <label for="berat">Berat</label>
                            <input type="text" name="berat" class="form-control" id="text" 
                            value="<?php echo e($produk->berat); ?>">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="harga">Harga</label>
                            <input type="text" name="harga" class="form-control" id="text" 
                            value="<?php echo e($produk->harga); ?>">
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="stok">Stok</label>
                            <input type="text" name="stok" class="form-control" id="text" 
                            value="<?php echo e($produk->stok); ?>">
                        </div>
                    </div>
                    
                </form>
				</div>
			</div>
		</div>
	</div>
    <div class="col-md-12">
        <div class="card full-height">
            <div class="card-body">
            <form method="post" action="" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <div class="card-title">Deskripsi Produk</div>
                    <br>
                    <label for="deskripsi"><?php echo $produk->deskripsi; ?></label>
                </div>
                
            </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Tugas Akhir\pokdakan\resources\views/kebutuhan-pengepul/show.blade.php ENDPATH**/ ?>